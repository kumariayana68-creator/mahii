import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.jaanmahii.app',
  appName: 'Mahii AI',
  webDir: 'dist',
};

export default config;
